
package ArbolBinari;

public class ArbolBinario {
   private Nodo raiz;

    public ArbolBinario() {
        this.raiz = null;
    }

    //insertar
    public void insertar(int valor) {
        raiz = insertarRecursivo(raiz, valor);
    }

    private Nodo insertarRecursivo(Nodo nodo, int valor) {
        if (nodo == null) {
            return new Nodo(valor);
        }
        if (valor < nodo.valor) {
            nodo.izquierdo = insertarRecursivo(nodo.izquierdo, valor);
        } else if (valor > nodo.valor) {
            nodo.derecho = insertarRecursivo(nodo.derecho, valor);
        }
        return nodo;
    }

    //buscar
    public boolean buscar(int valor) {
        return buscarRecursivo(raiz, valor);
    }

    private boolean buscarRecursivo(Nodo nodo, int valor) {
        if (nodo == null) {
            return false;
        }
        if (valor == nodo.valor) {
            return true;
        }
        return valor < nodo.valor ? buscarRecursivo(nodo.izquierdo, valor) : buscarRecursivo(nodo.derecho, valor);
    }

    //eliminar
    public void eliminar(int valor) {
        raiz = eliminarRecursivo(raiz, valor);
    }

    private Nodo eliminarRecursivo(Nodo nodo, int valor) {
        if (nodo == null) {
            return null;
        }
        if (valor < nodo.valor) {
            nodo.izquierdo = eliminarRecursivo(nodo.izquierdo, valor);
        } else if (valor > nodo.valor) {
            nodo.derecho = eliminarRecursivo(nodo.derecho, valor);
        } else {
            //Nodo con un solo hijo o sin hijo
            if (nodo.izquierdo == null) {
                return nodo.derecho;
            } else if (nodo.derecho == null) {
                return nodo.izquierdo;
            }
            //Nodo con dos hijos: obtener el sucesor inorden (el menor en el subárbol derecho)
            nodo.valor = minValue(nodo.derecho);
            nodo.derecho = eliminarRecursivo(nodo.derecho, nodo.valor);
        }
        return nodo;
    }

    private int minValue(Nodo nodo) {
        int minValue = nodo.valor;
        while (nodo.izquierdo != null) {
            minValue = nodo.izquierdo.valor;
            nodo = nodo.izquierdo;
        }
        return minValue;
    }

    //mostrar
    public void mostrarInorden() {
        mostrarInordenRecursivo(raiz);
        System.out.println();
    }

    private void mostrarInordenRecursivo(Nodo nodo) {
        if (nodo != null) {
            mostrarInordenRecursivo(nodo.izquierdo);
            System.out.print(nodo.valor + " ");
            mostrarInordenRecursivo(nodo.derecho);
        }
    }
}
  
